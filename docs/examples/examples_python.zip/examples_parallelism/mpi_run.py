r"""
mpi_run.py
----------

**Author(s)**: Romain Egele, Brett Eiffert.

mpi process creator
"""

import subprocess

from deephyper.evaluator import (
    parse_subprocess_result,
    profile,
)

@profile
def run_mpi_exe(job, dequed=None):
    x = job.parameters["x"]

    # The format of the print "DH-OUTPUT:(.+)\n" is strict if you use parse_suprocess_result
    command = f"mpirun -np {len(dequed)} echo DH-OUTPUT:{x}\n"
    completed_process = subprocess.run(command.split(), capture_output=True)
    objective = parse_subprocess_result(completed_process)

    # In the results.csv a new `m:dequed` will show the passed dequed values.
    return {"objective": objective, "metadata": {}}